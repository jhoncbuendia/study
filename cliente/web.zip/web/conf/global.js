var Global = {
  server_url: "http://localhost:20000/dev/api/",
  dev_url: "http://localhost:20000/dev/api/"
}
